this challenge is in node.js and mongodb and express
make sure you have everything install (>npm install )
how to run mongo database?
install mongodb in your cmd globally
run mongod in cmd (>mongod) //keep it running in the background
run mongo.exe to view the created databse or install robomongo and you can connect the database at port 27017 and view the database 
run login.js (>node login.js)	//this will create the database UserDb with users collections
